/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nguyen
 */
public class Fibonacci {

    public int[] fibonacciSeries(int n) {
        if (n <= 0) {
            return new int[0]; // Return an empty array for invalid input
        }

        int[] result = new int[n];
        result[0] = 0;
        if (n > 1) {
            result[1] = 1;
        }

        for (int i = 2; i < n; i++) {
            result[i] = result[i - 1] + result[i - 2];
        }

        return result;
    }

}
