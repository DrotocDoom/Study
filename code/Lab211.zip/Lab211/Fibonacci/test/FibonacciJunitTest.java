/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nguyen
 */
public class FibonacciJunitTest {

    public FibonacciJunitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of fibonacciSeries method, of class Fibonacci.
     */
    @Test
    public void testFibonacciSeries() {

        int input = 6;
        int[] actualResults;
        int[] expectedResults = {0, 1, 1, 2, 3, 5};

        Fibonacci fibonacci = new Fibonacci();
        actualResults = fibonacci.fibonacciSeries(input);

        System.out.println("testFibonacciSeries");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after print

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after print

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }

    @Test
    public void testZero() {

        int input = 0;
        int[] actualResults;
        int[] expectedResults = {};

        Fibonacci fibonacci = new Fibonacci();
        actualResults = fibonacci.fibonacciSeries(input);

        System.out.println("testZero");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after print

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after print

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }

    @Test
    public void testOne() {
        int input = 1;
        int[] actualResults;
        int[] expectedResults = {0};

        Fibonacci fibonacci = new Fibonacci();
        actualResults = fibonacci.fibonacciSeries(input);

        System.out.println("testOne");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after print

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after print

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }

    @Test
    public void testThree() {
        int input = 3;
        int[] actualResults;
        int[] expectedResults = {0, 1, 1};

        Fibonacci fibonacci = new Fibonacci();
        actualResults = fibonacci.fibonacciSeries(input);

        System.out.println("testOne");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after print

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after print

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }

    @Test
    public void testNegateValues() {

        int input = -5;
        int[] actualResults;
        int[] expectedResults = {};

        Fibonacci fibonacci = new Fibonacci();
        actualResults = fibonacci.fibonacciSeries(input);

        System.out.println("testNegateValues");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after print

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after print

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }

    @Test
    public void testLargeInput() {

        int input = 20;
        int[] actualResults;
        int[] expectedResults = {
            0, 1, 1, 2, 3, 5, 8, 13, 21, 34,
            55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181
        };

        Fibonacci fibonacci = new Fibonacci();
        actualResults = fibonacci.fibonacciSeries(input);

        System.out.println("testLargeInput");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after print

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after print

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }
}
