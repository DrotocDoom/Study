/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import LinearSearch.utils.Search;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nguyen
 */
public class SearchTest {

    public SearchTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of linearSearch method, of class Search.
     */
    @Test
    public void testLinearSearch() {
        int input = 4;
        int[] myArray = {1, 2, 3, 4, 5, 17, 7, 18, 8, 9, 10};
        int actualResults;
        int expectedResults = 4;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testLinearSearch");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testNotFound() {
        int input = 0;
        int[] myArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int actualResults;
        int expectedResults = -1;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testNotFound");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testArrayEmpty() {
        int input = 4;
        int[] myArray = {};
        int actualResults;
        int expectedResults = -1;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testArrayEmpty");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testUnsortArray() {
        int input = 4;
        int[] myArray = {8, 2, 5, 1, 9, 4, 7, 3, 6, 10};
        int actualResults;
        int expectedResults = 6;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testUnsortArray");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testFirstElement() {
        int input = 1;
        int[] myArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int actualResults;
        int expectedResults = 1;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testFirstElement");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testLastElement() {
        int input = 10;
        int[] myArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int actualResults;
        int expectedResults = 10;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testLastElement");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testAllSame() {
        int input = 4;
        int[] myArray = {4, 4, 4, 4, 4, 4, 4, 4, 4};
        int actualResults;
        int expectedResults = 1;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testAllSame");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testDuplicateValues() {
        int input = 2;
        int[] myArray = {1, 2, 2, 3, 3, 4, 4, 6, 7, 8, 8, 9, 13};
        int actualResults;
        int expectedResults = 2;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testDuplicateValues");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testMixedValues() {
        int input = -2;
        int[] myArray = {-4, -2, -1, 0, 3, 5, 7, 8, 10, 12};
        int actualResults;
        int expectedResults = 2;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testDuplicateValues");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testSignNumber() {
        int input = 4;
        int[] myArray = {4};
        int actualResults;
        int expectedResults = 1;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testDuplicateValues");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testAlreadySortedArray() {
        int input = 5;
        int[] myArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int actualResults;
        int expectedResults = 5;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testAlreadySortedArray");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testReverseSortedArray() {
        int input = 1;
        int[] myArray = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
        int actualResults;
        int expectedResults = 10;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testReverseSortedArray");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testNegativeArray() {
        int input = -7;
        int[] myArray = {-9, -8, -7, -6, -5, -4, -3, -2, -1};
        int actualResults;
        int expectedResults = 3;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testNegativeArray");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testEvenArray() {
        int input = 0;
        int[] myArray = {-8, -6, -4, -2, 0, 2, 6, 8, 10};
        int actualResults;
        int expectedResults = 5;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testEvenArray");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }

    @Test
    public void testOddArray() {
        int input = -1;
        int[] myArray = {-11, -7, -1, 3, 7, 15, 19, 23};
        int actualResults;
        int expectedResults = 3;
        Search search = new Search();
        actualResults = search.linearSearch(myArray, input);

        // Print actual results
        System.out.println("testOddArray");
        System.out.print("actualResults: " + actualResults);
        System.out.println();

        // Print expected results
        System.out.print("expectedResults: " + expectedResults);

        System.out.println("");
        System.out.println();
        assertEquals(expectedResults, actualResults);
    }
    /**
     * Test of printResult method, of class Search.
     */
}
