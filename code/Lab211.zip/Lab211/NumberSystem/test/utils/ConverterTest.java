/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import NumberSystem.utils.Converter;
import java.math.BigInteger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nguyen
 */
public class ConverterTest {

    public ConverterTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of convertFromDEC method, of class Converter.
     */
    @Test
    public void testConvertHEXFromDEC() {
        System.out.println("testConvertHEXFromDEC");
        String input = "1000000";
        String actualResults;
        String expectedResults = "F4240";
        Converter converter = new Converter();
        actualResults = converter.convertBase(input, 10, 16);
        assertEquals(actualResults, expectedResults);
        System.out.println("actualResults: " + actualResults);
        System.out.println("expectedResults: " + expectedResults);
        System.out.println("");
    }

    @Test
    public void testConvertHEXFromBIN() {
        System.out.println("testConvertHEXFromBIN");
        String input = "10111000";
        String actualResults;
        String expectedResults = "B8";
        Converter converter = new Converter();
        actualResults = converter.convertBase(input + "", 2, 16);
        assertEquals(actualResults, expectedResults);
        System.out.println("actualResults: " + actualResults);
        System.out.println("expectedResults: " + expectedResults);
        System.out.println("");
    }

    @Test
    public void testConvertBINFromDEC() {
        System.out.println("testConvertBINFromDEC");
        String input = "1000000";
        String actualResults;
        String expectedResults = "11110100001001000000";
        Converter converter = new Converter();
        actualResults = converter.convertBase(input, 10, 2);
        assertEquals(actualResults, expectedResults);
        System.out.println("actualResults: " + actualResults);
        System.out.println("expectedResults: " + expectedResults);
        System.out.println("");
    }

    @Test
    public void testConvertBINFromHEX() {
        System.out.println("testConvertBINFromHEX");
        String input = "19AC";
        String actualResults;
        String expectedResults = "1100110101100";
        Converter converter = new Converter();
        actualResults = converter.convertBase(input, 16, 2);
        assertEquals(actualResults, expectedResults);
        System.out.println("actualResults: " + actualResults);
        System.out.println("expectedResults: " + expectedResults);
        System.out.println("");
    }

    @Test
    public void testConvertDEXFromHEX() {
        System.out.println("testConvertDEXFromHEX");
        String input = "19AC";
        String actualResults;
        String expectedResults = "6572";
        Converter converter = new Converter();
        actualResults = converter.convertBase(input, 16, 10);
        assertEquals(actualResults, expectedResults);
        System.out.println("actualResults: " + actualResults);
        System.out.println("expectedResults: " + expectedResults);
        System.out.println("");
    }
    
        @Test
    public void testConvertDEXFromBIN() {
        System.out.println("testConvertDEXFromBIN");
        String input = "1100110101100";
        String actualResults;
        String expectedResults = "6572";
        Converter converter = new Converter();
        actualResults = converter.convertBase(input, 2, 10);
        assertEquals(actualResults, expectedResults);
        System.out.println("actualResults: " + actualResults);
        System.out.println("expectedResults: " + expectedResults);
        System.out.println("");
    }

}
