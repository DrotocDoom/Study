/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordscount;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

/**
 *
 * @author nguyen
 */
public class WordsCount {

    public Map<String, Integer> wordsCount(String content) {
        StringTokenizer tokenizer = new StringTokenizer(content.toLowerCase(), " \t\n\r\f,.?!;:+-=\"'()[]{}<>\\/1234567890");

        Map<String, Integer> words = new HashMap<>();

        while (tokenizer.hasMoreTokens()) {
            String word = tokenizer.nextToken();
            if (!words.containsKey(word)) {
                words.put(word, 0);
            }
            words.put(word, words.get(word) + 1);
        }

        return words;
    }

    public Map<Character, Integer> charsCount(String content) {
        Map<Character, Integer> charCountMap = new HashMap<>();

        for (char c : content.toCharArray()) {
            if (c != ' ') { // Skip spaces
                char lowerCaseChar = Character.toLowerCase(c); // Convert character to lowercase
                charCountMap.put(lowerCaseChar, charCountMap.getOrDefault(lowerCaseChar, 0) + 1);
            }
        }

        return charCountMap;
    }

    public static void main(String[] args) {
        String a = "!@#$%^&*()";
        Map<Character, Integer> actualCharsCount = new WordsCount().charsCount(a);
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
    }
}
