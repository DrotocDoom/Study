/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordscount;

import java.util.HashMap;
import java.util.Map;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nguyen
 */
public class WordsCountTest {

    public WordsCountTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of wordsCount method, of class WordsCount.
     */
    @Test
    public void testCounts() {
        System.out.println("testCounts");
        String content = "hello world"; // Input content

        WordsCount word = new WordsCount();

        // Define the expected results for wordsCount
        Map<String, Integer> expectedWordsCount = new HashMap<>();
        expectedWordsCount.put("hello", 1);
        expectedWordsCount.put("world", 1);

        // Define the expected results for charsCount
        Map<Character, Integer> expectedCharsCount = new HashMap<>();
        expectedCharsCount.put('w', 1);
        expectedCharsCount.put('d', 1);
        expectedCharsCount.put('e', 1);
        expectedCharsCount.put('r', 1);
        expectedCharsCount.put('o', 2);
        expectedCharsCount.put('l', 3);
        expectedCharsCount.put('h', 1);

        // Call the methods and get actual results
        Map<String, Integer> actualWordsCount = word.wordsCount(content);
        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        // Perform the assertions to compare expected and actual results
        assertEquals(expectedWordsCount, actualWordsCount);
        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for wordsCount
        System.out.println("Expected Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : expectedWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : actualWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

    @Test
    public void testCountsUppercase() {
        System.out.println("testCountsUppercase");
        String content = "HELLO WORLD"; // Input content

        WordsCount word = new WordsCount();

        // Define the expected results for wordsCount
        Map<String, Integer> expectedWordsCount = new HashMap<>();
        expectedWordsCount.put("hello", 1);
        expectedWordsCount.put("world", 1);

        // Define the expected results for charsCount
        Map<Character, Integer> expectedCharsCount = new HashMap<>();
        expectedCharsCount.put('w', 1);
        expectedCharsCount.put('d', 1);
        expectedCharsCount.put('e', 1);
        expectedCharsCount.put('r', 1);
        expectedCharsCount.put('o', 2);
        expectedCharsCount.put('l', 3);
        expectedCharsCount.put('h', 1);

        // Call the methods and get actual results
        Map<String, Integer> actualWordsCount = word.wordsCount(content);
        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        // Perform the assertions to compare expected and actual results
        assertEquals(expectedWordsCount, actualWordsCount);
        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for wordsCount
        System.out.println("Expected Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : expectedWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : actualWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

    @Test
    public void testCountsMixedCase() {
        System.out.println("testCountsMixedCase");
        String content = "ThIs Is A MiXeD CaSe StRiNg"; // Input content

        WordsCount word = new WordsCount();

        // Define the expected results for wordsCount
        Map<String, Integer> expectedWordsCount = new HashMap<>();
        expectedWordsCount.put("this", 1);
        expectedWordsCount.put("is", 1);
        expectedWordsCount.put("a", 1);
        expectedWordsCount.put("mixed", 1);
        expectedWordsCount.put("case", 1);
        expectedWordsCount.put("string", 1);

        // Define the expected results for charsCount
        Map<Character, Integer> expectedCharsCount = new HashMap<>();
        expectedCharsCount.put('a', 2);
        expectedCharsCount.put('c', 1);
        expectedCharsCount.put('d', 1);
        expectedCharsCount.put('e', 2);
        expectedCharsCount.put('g', 1);
        expectedCharsCount.put('h', 1);
        expectedCharsCount.put('i', 4);
        expectedCharsCount.put('m', 1);
        expectedCharsCount.put('n', 1);
        expectedCharsCount.put('r', 1);
        expectedCharsCount.put('s', 4);
        expectedCharsCount.put('t', 2);
        expectedCharsCount.put('x', 1);

        // Call the methods and get actual results
        Map<String, Integer> actualWordsCount = word.wordsCount(content);
        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        // Perform the assertions to compare expected and actual results
        assertEquals(expectedWordsCount, actualWordsCount);
        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for wordsCount
        System.out.println("Expected Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : expectedWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : actualWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

    @Test
    public void testCountsSpecialCharacters() {
        System.out.println("testCountsSpecialCharacters");
        String content = "!@#$%^&*()"; // Input content

        WordsCount word = new WordsCount();

        Map<Character, Integer> expectedCharsCount = new HashMap<>();
        expectedCharsCount.put('!', 1);
        expectedCharsCount.put('@', 1);
        expectedCharsCount.put('#', 1);
        expectedCharsCount.put('$', 1);
        expectedCharsCount.put('%', 1);
        expectedCharsCount.put('^', 1);
        expectedCharsCount.put('&', 1);
        expectedCharsCount.put('*', 1);
        expectedCharsCount.put('(', 1);
        expectedCharsCount.put(')', 1);

        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

    @Test
    public void testCountsMixedAllCase() {
        System.out.println("testCountsMixedCase");
        String content = "abc @#$"; // Input content

        WordsCount word = new WordsCount();

        // Define the expected results for wordsCount
        Map<String, Integer> expectedWordsCount = new HashMap<>();
        expectedWordsCount.put("abc", 1);
        expectedWordsCount.put("@#$", 1);

        // Define the expected results for charsCount
        Map<Character, Integer> expectedCharsCount = new HashMap<>();
        expectedCharsCount.put('a', 1);
        expectedCharsCount.put('b', 1);
        expectedCharsCount.put('c', 1);
        expectedCharsCount.put('@', 1);
        expectedCharsCount.put('#', 1);
        expectedCharsCount.put('$', 1);

        // Call the methods and get actual results
        Map<String, Integer> actualWordsCount = word.wordsCount(content);
        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        // Perform the assertions to compare expected and actual results
        assertEquals(expectedWordsCount, actualWordsCount);
        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for wordsCount
        System.out.println("Expected Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : expectedWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : actualWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

    @Test
    public void testCountAllWord() {
        System.out.println("testCountAllWord");
        String content = "hello hello hello"; // Input content

        WordsCount word = new WordsCount();

        // Define the expected results for wordsCount
        Map<String, Integer> expectedWordsCount = new HashMap<>();
        expectedWordsCount.put("hello", 3);
        // Define the expected results for charsCount
        Map<Character, Integer> expectedCharsCount = new HashMap<>();
        expectedCharsCount.put('h', 3);
        expectedCharsCount.put('l', 6);
        expectedCharsCount.put('e', 3);
        expectedCharsCount.put('o', 3);
        // Call the methods and get actual results
        Map<String, Integer> actualWordsCount = word.wordsCount(content);
        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        // Perform the assertions to compare expected and actual results
        assertEquals(expectedWordsCount, actualWordsCount);
        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for wordsCount
        System.out.println("Expected Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : expectedWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : actualWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

    @Test
    public void testCountAllCharacter() {
        System.out.println("testCountAllCharacter");
        String content = "aaaaaaaaaa"; // Input content

        WordsCount word = new WordsCount();

        // Define the expected results for wordsCount
        Map<String, Integer> expectedWordsCount = new HashMap<>();
        expectedWordsCount.put("aaaaaaaaaa", 1);
        // Define the expected results for charsCount
        Map<Character, Integer> expectedCharsCount = new HashMap<>();
        expectedCharsCount.put('a', 10);

        // Call the methods and get actual results
        Map<String, Integer> actualWordsCount = word.wordsCount(content);
        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        // Perform the assertions to compare expected and actual results
        assertEquals(expectedWordsCount, actualWordsCount);
        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for wordsCount
        System.out.println("Expected Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : expectedWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : actualWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

    @Test
    public void testEmptyString() {
        System.out.println("testEmptyString");
        String content = ""; // Input content

        WordsCount word = new WordsCount();

        // Define the expected results for wordsCount
        Map<String, Integer> expectedWordsCount = new HashMap<>();
        // Define the expected results for charsCount

        Map<Character, Integer> expectedCharsCount = new HashMap<>();

        // Call the methods and get actual results
        Map<String, Integer> actualWordsCount = word.wordsCount(content);
        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        // Perform the assertions to compare expected and actual results
        assertEquals(expectedWordsCount, actualWordsCount);
        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for wordsCount
        System.out.println("Expected Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : expectedWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : actualWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

    @Test
    public void testWordsCountWordFrequency() {
        System.out.println("testWordsCountWordFrequency");
        String content = "apple apple apple banana"; // Input content

        WordsCount word = new WordsCount();

        // Define the expected results for wordsCount
        Map<String, Integer> expectedWordsCount = new HashMap<>();
        expectedWordsCount.put("apple", 3);
        expectedWordsCount.put("banana", 1);
        // Define the expected results for charsCount
        Map<Character, Integer> expectedCharsCount = new HashMap<>();
        expectedCharsCount.put('a', 6);
        expectedCharsCount.put('p', 6);
        expectedCharsCount.put('l', 3);
        expectedCharsCount.put('e', 3);
        expectedCharsCount.put('b', 1);
        expectedCharsCount.put('n', 2);

        // Call the methods and get actual results
        Map<String, Integer> actualWordsCount = word.wordsCount(content);
        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        // Perform the assertions to compare expected and actual results
        assertEquals(expectedWordsCount, actualWordsCount);
        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for wordsCount
        System.out.println("Expected Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : expectedWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : actualWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

    @Test
    public void testSingleWord() {
        System.out.println("testSingleWord");
        String content = "apple"; // Input content

        WordsCount word = new WordsCount();

        // Define the expected results for wordsCount
        Map<String, Integer> expectedWordsCount = new HashMap<>();
        expectedWordsCount.put("apple", 1);
        // Define the expected results for charsCount
        Map<Character, Integer> expectedCharsCount = new HashMap<>();
        expectedCharsCount.put('a', 1);
        expectedCharsCount.put('p', 2);
        expectedCharsCount.put('l', 1);
        expectedCharsCount.put('e', 1);

        // Call the methods and get actual results
        Map<String, Integer> actualWordsCount = word.wordsCount(content);
        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        // Perform the assertions to compare expected and actual results
        assertEquals(expectedWordsCount, actualWordsCount);
        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for wordsCount
        System.out.println("Expected Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : expectedWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : actualWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

    @Test
    public void testSingleCharacter() {
        System.out.println("testSingleCharacter");
        String content = "a"; // Input content

        WordsCount word = new WordsCount();

        // Define the expected results for wordsCount
        Map<String, Integer> expectedWordsCount = new HashMap<>();
        expectedWordsCount.put("a", 1);
        // Define the expected results for charsCount
        Map<Character, Integer> expectedCharsCount = new HashMap<>();
        expectedCharsCount.put('a', 1);

        // Call the methods and get actual results
        Map<String, Integer> actualWordsCount = word.wordsCount(content);
        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        // Perform the assertions to compare expected and actual results
        assertEquals(expectedWordsCount, actualWordsCount);
        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for wordsCount
        System.out.println("Expected Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : expectedWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : actualWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

    @Test
    public void testCharsCountWithSpaces() {
        System.out.println("testCharsCountWithSpaces");
        String content = "a p p l e"; // Input content

        WordsCount word = new WordsCount();

        // Define the expected results for wordsCount
        Map<String, Integer> expectedWordsCount = new HashMap<>();
        expectedWordsCount.put("a", 1);
        expectedWordsCount.put("p", 2);
        expectedWordsCount.put("l", 1);
        expectedWordsCount.put("e", 1);
        // Define the expected results for charsCount
        Map<Character, Integer> expectedCharsCount = new HashMap<>();
        expectedCharsCount.put('a', 1);
        expectedCharsCount.put('p', 2);
        expectedCharsCount.put('l', 1);
        expectedCharsCount.put('e', 1);

        // Call the methods and get actual results
        Map<String, Integer> actualWordsCount = word.wordsCount(content);
        Map<Character, Integer> actualCharsCount = word.charsCount(content);

        // Perform the assertions to compare expected and actual results
        assertEquals(expectedWordsCount, actualWordsCount);
        assertEquals(expectedCharsCount, actualCharsCount);

        // Print expected and actual results for wordsCount
        System.out.println("Expected Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : expectedWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for wordsCount:");
        for (Map.Entry<String, Integer> entry : actualWordsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        // Print expected and actual results for charsCount
        System.out.println("Expected Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : expectedCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }

        System.out.println("Actual Results for charsCount:");
        for (Map.Entry<Character, Integer> entry : actualCharsCount.entrySet()) {
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
        System.out.println("");
    }

}
