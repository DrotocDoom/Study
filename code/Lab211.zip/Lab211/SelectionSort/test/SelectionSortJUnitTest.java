 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import SelectionSort.Sort;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nguyen
 */
public class SelectionSortJUnitTest {

    public SelectionSortJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of selectionSort method, of class Sort.
     */
    @Test
    public void testSelectionSort() {
        int[] myArray = {5, 8, 3, 1, 9, 7, 2, 6, 4, 10};
        int[] actualResults;
        int[] expectedResults = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        Sort sort = new Sort();
        actualResults = sort.selectionSort(myArray);

        // Print actual results
        System.out.println("testSelectionSort");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after printing the actual results

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after printing the expected results

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }

    @Test
    public void testZero() {
        int[] myArray = {};
        int[] actualResults;
        int[] expectedResults = {};
        Sort sort = new Sort();
        actualResults = sort.selectionSort(myArray);

        // Print actual results
        System.out.println("testZero");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after printing the actual results

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after printing the expected results

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }
    
    @Test
    public void testNegativeNumber() {
        int[] myArray = {-3, -1, -4, -1, -5, -9, -2, -6, -5, -3};
        int[] actualResults;
        int[] expectedResults = {-9, -6, -5, -5, -4, -3, -3, -2, -1, -1};
        Sort sort = new Sort();
        actualResults = sort.selectionSort(myArray);

        // Print actual results
        System.out.println("testNegativeNumber");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after printing the actual results

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after printing the expected results

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    } 
    
    @Test
    public void testEvenNumber() {
        int[] myArray = {4, 10, 6, 8, 2, 16, 12, 20, 14, 18};
        int[] actualResults;
        int[] expectedResults = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
        Sort sort = new Sort();
        actualResults = sort.selectionSort(myArray);

        // Print actual results
        System.out.println("testEvenNumber");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after printing the actual results

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after printing the expected results

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }
    
    
    @Test
    public void testOddNumber() {
        int[] myArray = {7, 3, 9, 5, 11, 1, 13};
        int[] actualResults;
        int[] expectedResults = {1, 3, 5, 7, 9, 11, 13};
        Sort sort = new Sort();
        actualResults = sort.selectionSort(myArray);

        // Print actual results
        System.out.println("testOddNumber");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after printing the actual results

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after printing the expected results

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }
    
    @Test
    public void testSignNumber() {
        int[] myArray = {14};
        int[] actualResults;
        int[] expectedResults = {14};
        Sort sort = new Sort();
        actualResults = sort.selectionSort(myArray);

        // Print actual results
        System.out.println("testSignNumber");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after printing the actual results

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after printing the expected results

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }
    
    @Test
    public void testMixedValues() {
        int[] myArray = {7, -2, 0, 8, -1};
        int[] actualResults;
        int[] expectedResults = {-2, -1, 0, 7, 8};
        Sort sort = new Sort();
        actualResults = sort.selectionSort(myArray);

        // Print actual results
        System.out.println("testMixedValues");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after printing the actual results

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after printing the expected results

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }
    
    @Test
    public void testAllSameValues() {
        int[] myArray = {5, 5, 5, 5, 5};
        int[] actualResults;
        int[] expectedResults = {5, 5, 5, 5, 5};
        Sort sort = new Sort();
        actualResults = sort.selectionSort(myArray);

        // Print actual results
        System.out.println("testAllSameValues");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after printing the actual results

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after printing the expected results

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }
    
    @Test
    public void testDuplicateValues() {
        int[] myArray = {3, 2, 2, 1, 3};
        int[] actualResults;
        int[] expectedResults = {1, 2, 2, 3, 3};
        Sort sort = new Sort();
        actualResults = sort.selectionSort(myArray);

        // Print actual results
        System.out.println("testDuplicateValues");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after printing the actual results

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after printing the expected results

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }
    
    
    @Test
    public void testAlreadySortedArray() {
        int[] myArray = {1, 2, 3, 4, 5};
        int[] actualResults;
        int[] expectedResults = {1, 2, 3, 4, 5};
        Sort sort = new Sort();
        actualResults = sort.selectionSort(myArray);

        // Print actual results
        System.out.println("testAlreadySortedArray");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after printing the actual results

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after printing the expected results

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }
    
    @Test
    public void testReverseSortedArray() {
        int[] myArray = {5, 4, 3, 2, 1};
        int[] actualResults;
        int[] expectedResults = {1, 2, 3, 4, 5};
        Sort sort = new Sort();
        actualResults = sort.selectionSort(myArray);

        // Print actual results
        System.out.println("testReverseSortedArray");
        System.out.print("actualResults: ");
        for (int num : actualResults) {
            System.out.print(num + " ");
        }
        System.out.println(); // Add a newline after printing the actual results

        // Print expected results
        System.out.print("expectedResults: ");
        for (int num : expectedResults) {
            System.out.print(num + " ");
        }
        System.out.println("");
        System.out.println(); // Add a newline after printing the expected results

        // Use assertArrayEquals to compare the arrays
        assertArrayEquals(expectedResults, actualResults);
    }

}
